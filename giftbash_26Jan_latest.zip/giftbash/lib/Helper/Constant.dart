final String appName = 'GIFTBASH';

final String packageName = 'com.giftbash.user';
final String androidLink = 'https://play.google.com/store/apps/details?id=';

final String iosPackage = 'com.giftbash.user';
final String iosLink = 'your ios link here';
final String appStoreId = 'com.giftbash.user';

final String deepLinkUrlPrefix = 'https://alpha.ecommerce.link';
final String deepLinkName = 'alpha.ecommerce.link';

final int timeOut = 50;
const int perPage = 10;

final String baseUrl = 'https://developmentalphawizz.com/alphaecommerce_new/app/v1/api/';
final String imageUrl = 'https://developmentalphawizz.com/alphaecommerce_new/';

final String jwtKey = "e1e421dceee9ea718ab764ea4fdef95629e7f415";
